<?php

function xmldb_auth_mnet_install() {
    global $CFG, $DB;

}
